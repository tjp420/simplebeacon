/**
 * JSON reporter for samplebeacon scan results.
 */

function formatJsonReport(report, gateResult = null) {
    return {
        ...report,
        gate: gateResult
            ? {
                pass: gateResult.pass,
                failOn: gateResult.failOn,
                warnOn: gateResult.warnOn,
                blockingCount: gateResult.blockingIssues.length,
                warningCount: gateResult.warningIssues.length
            }
            : null
    };
}

module.exports = {
    formatJsonReport
};
