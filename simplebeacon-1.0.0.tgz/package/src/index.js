/**
 * samplebeacon — public API
 */

const fs = require('fs');
const path = require('path');
const { detectProjectProfile, resolvePlatformRoot } = require('./project-detect');
const {
    loadSamplebeaconConfig,
    loadCentralDataConfig,
    resolveScanPaths,
    resolvePathFromBase,
    normalizeRelativePath,
    getInitTemplates,
    DEFAULT_MOCK_SCAN_RELATIVE_PATHS,
    DEFAULT_CONSISTENCY_ANCHOR_SAMPLES,
    DEFAULT_BASELINE
} = require('./config');
const {
    runScan,
    scanMockDataDirectories,
    formatBytes,
    categoryForExt,
    validateSampleSchema,
    groupIssues,
    isBlockingIssue,
    countBySeverity
} = require('./scan');
const { evaluateGate } = require('./gate');
const { formatTextReport } = require('./reporters/text');
const { formatJsonReport } = require('./reporters/json');
const { formatGithubComment, formatGithubStepSummary, postGithubComment } = require('./reporters/github-comment');
const { buildAssessmentReport } = require('./assessment');
const { evaluateComplianceChecklist, loadComplianceChecklist } = require('./compliance-checklist');
const {
    redactSecretsInString,
    sanitizeScanReport,
    sanitizeAssessment,
    sanitizeReportForCloudUpload
} = require('./lib/report-sanitizer');
const { syncJestBaseline, verifyJestBaseline } = require('./baseline-sync');
const { installSamplebeaconHook, buildHookScript } = require('./hook-install');

function resolveMockDataScanPaths(baseDir, extraPaths = []) {
    const { platformRoot } = resolvePlatformRoot(baseDir);
    const config = loadSamplebeaconConfig(platformRoot);
    return resolveScanPaths(platformRoot, config, extraPaths);
}

function getRepositoryAuditBaseline(baseDir) {
    return loadSamplebeaconConfig(baseDir).baseline;
}

function getConsistencyAnchorSamples(baseDir) {
    return loadSamplebeaconConfig(baseDir).consistencyAnchorSamples;
}

function initSamplebeacon(baseDir, options = {}) {
    const root = path.resolve(baseDir);
    const samplebeaconDir = path.join(root, '.samplebeacon');
    const templates = getInitTemplates(root, options);
    fs.mkdirSync(samplebeaconDir, { recursive: true });

    const configPath = path.join(samplebeaconDir, 'config.json');
    const baselinePath = path.join(samplebeaconDir, 'baseline.json');
    const created = { configPath, baselinePath, samplebeaconDir, profile: templates.profile, detected: templates.detected };

    if (!fs.existsSync(configPath)) {
        fs.writeFileSync(configPath, `${JSON.stringify(templates.config, null, 2)}\n`, 'utf8');
        created.configCreated = true;
    } else {
        created.configCreated = false;
        created.configSkipped = true;
    }
    if (!fs.existsSync(baselinePath)) {
        fs.writeFileSync(baselinePath, `${JSON.stringify(templates.baseline, null, 2)}\n`, 'utf8');
        created.baselineCreated = true;
    } else {
        created.baselineCreated = false;
        created.baselineSkipped = true;
    }

    return created;
}

module.exports = {
    loadSamplebeaconConfig,
    loadCentralDataConfig,
    resolveScanPaths,
    resolveMockDataScanPaths,
    resolvePathFromBase,
    normalizeRelativePath,
    getInitTemplates,
    initSamplebeacon,
    getRepositoryAuditBaseline,
    getConsistencyAnchorSamples,
    DEFAULT_MOCK_SCAN_RELATIVE_PATHS,
    DEFAULT_CONSISTENCY_ANCHOR_SAMPLES,
    DEFAULT_BASELINE,
    runScan,
    scanMockDataDirectories,
    formatBytes,
    categoryForExt,
    validateSampleSchema,
    groupIssues,
    isBlockingIssue,
    countBySeverity,
    evaluateGate,
    formatTextReport,
    formatJsonReport,
    formatGithubComment,
    formatGithubStepSummary,
    postGithubComment,
    buildAssessmentReport,
    evaluateComplianceChecklist,
    loadComplianceChecklist,
    redactSecretsInString,
    sanitizeScanReport,
    sanitizeAssessment,
    sanitizeReportForCloudUpload,
    syncJestBaseline,
    verifyJestBaseline,
    installSamplebeaconHook,
    buildHookScript,
    detectProjectProfile,
    resolvePlatformRoot
};
