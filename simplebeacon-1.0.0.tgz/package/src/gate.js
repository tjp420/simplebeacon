/**
 * Evaluate samplebeacon gate against configured severities.
 */

const { isBlockingIssue } = require('./scan');

function evaluateGate(report, gateConfig = {}) {
    const failOn = new Set(gateConfig.failOn || ['high']);
    const warnOn = new Set(gateConfig.warnOn || ['medium', 'low']);
    const rawIssues = report.rawIssues || [];

    const blockingIssues = rawIssues.filter(
        (issue) => failOn.has(issue.severity) && isBlockingIssue(issue)
    );
    const warningIssues = rawIssues.filter(
        (issue) => warnOn.has(issue.severity) && isBlockingIssue(issue)
    );

    return {
        pass: blockingIssues.length === 0,
        blockingIssues,
        warningIssues,
        failOn: [...failOn],
        warnOn: [...warnOn]
    };
}

module.exports = {
    evaluateGate
};
