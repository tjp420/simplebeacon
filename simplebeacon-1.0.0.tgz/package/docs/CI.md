# CI Integration

**Quick copy:** [GITHUB-ACTION-QUICKSTART.md](./GITHUB-ACTION-QUICKSTART.md) — standalone `npx` workflow and composite action examples.

## GitHub Actions (monorepo)

```yaml
name: Samplebeacon
on: [pull_request, push]
jobs:
  samplebeacon:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
      - run: npm ci
        working-directory: ai-platform
      - run: npm run samplebeacon:report
        working-directory: ai-platform
      - run: npm run samplebeacon:comment
        if: github.event_name == 'pull_request'
        working-directory: ai-platform
        env:
          GITHUB_TOKEN: ${{ github.token }}
```

## Composite action (standalone or monorepo)

```yaml
- uses: your-org/ai-platform/action@v1
  with:
    path: .
    fail-on: high
    with-jest: false
    post-comment: true
```

The action auto-detects monorepo layout (`packages/samplebeacon-cli`) or uses `npx samplebeacon` for external repos.

## GitLab CI

```yaml
samplebeacon:
  image: node:20
  script:
    - npm install -g samplebeacon
    - samplebeacon init --profile minimal
    - samplebeacon scan --gate --format json --output .samplebeacon/report.json
  artifacts:
    paths:
      - .samplebeacon/report.json
```

## CircleCI

```yaml
jobs:
  samplebeacon:
    docker:
      - image: cimg/node:20.0
    steps:
      - checkout
      - run: npx samplebeacon scan --gate
```

## Environment variables

| Variable | Purpose |
|----------|---------|
| `GITHUB_TOKEN` | Post PR comments |
| `GITHUB_REPOSITORY` | `owner/repo` slug |
| `GITHUB_EVENT_PULL_REQUEST_NUMBER` | PR number for comments |
| `NO_COLOR` | Disable colored CLI output |
| `CI=true` | Standard CI mode for Jest baseline |
| `SAMPLEBEACON_DASHBOARD_URL` | Optional webhook for live dashboard sync (see [DOCKER.md](./DOCKER.md)) |
| `SAMPLEBEACON_DASHBOARD_TOKEN` | Bearer token for dashboard webhook |

## Docker local stack

See [DOCKER.md](./DOCKER.md) for `docker-compose.samplebeacon.yml` — dashboard, metrics collector, and optional Postgres/Redis.
