# Samplebeacon — Naming & Branding Research

Research date: **May 2026**  
Product version at rename: **v1.1.0**  
Purpose: document why we renamed from Truthcheck / Cascade AI, what names were evaluated, and what to verify before public launch.

---

## Executive summary

| Decision | Choice |
|----------|--------|
| **Product name** | **Samplebeacon** |
| **npm package** | `samplebeacon` (unscoped) |
| **CLI command** | `samplebeacon` |
| **Config directory** | `.samplebeacon/` |
| **Company / program umbrella** | Avoid leading with **Cascade AI** — name is taken by a funded HR/IT startup |
| **Previous names** | `@cascade/truthcheck`, Cascade Truthcheck, Truthcheck |

**Tagline (approved):**  
> CI beacon for mock leaks, fiction KPIs, and credential patterns in sample JSON.

**Elevator pitch:**  
> AI-assisted development leaves mock JSON, demo credentials, and inflated KPIs in repos. Samplebeacon scans configured sample directories and production paths, validates schemas, and fails the build before fiction ships — in under a second for typical projects.

---

## Why not "Cascade AI"?

**Cascade AI is actively used** by another company — not available as a greenfield brand.

| | |
|---|---|
| **Site** | [gocascade.ai](https://gocascade.ai/) |
| **Product** | Enterprise agentic workflow automation for **HR & IT** (benefits, leave, ITSM, Workday/ServiceNow) |
| **Company** | Cascade Innovations Inc., Bellevue, WA |
| **Funding** | ~$3.75M seed (2024, e.g. Gradient; covered by GeekWire) |
| **Distribution** | [Microsoft Marketplace listing](https://marketplace.microsoft.com/en-us/product/cascade.b17a458d-f765-4383-838e-9bb72fdd4630) |
| **LinkedIn** | [linkedin.com/company/cascade-ai](https://linkedin.com/company/cascade-ai) |

### Recommended brand hierarchy

| Layer | Name | Use for |
|-------|------|---------|
| **Shippable product** | **Samplebeacon** | npm, CLI, GitHub Action, marketing |
| **Internal monorepo** | Cascade AI Platform | Frozen dashboard / dogfood only |
| **Avoid as primary external brand** | Cascade AI | Collides with gocascade.ai; carries old dashboard-fiction baggage |

**Approved external phrasing:** *Samplebeacon* or *Samplebeacon by [your org name]* — not “🚀 Cascade AI” as the product label.

---

## Competitive landscape (same problem space)

Know these when positioning Samplebeacon — they overlap partially but are not identical.

| Product | Focus | Overlap with Samplebeacon |
|---------|-------|---------------------------|
| [Guardrail](https://github.com/Guardrail-Official/guardrail) | Mock data, dead routes, auth, secrets, UI/API drift, CI gate | **High** — closest direct competitor narrative |
| [GreenGate](https://github.com/ThinkGrid-Labs/greengate) | Rust CI gate: secrets, SAST, supply chain, coverage | Medium — security/quality gate, not sample JSON fiction |
| [baseline-check](https://www.npmjs.com/package/baseline-check) | **Web platform** Baseline feature compliance | **Name collision only** — different category |
| [Mockoon](https://mockoon.com/) / MockMaster | Mock API servers & fixtures | Low — mocking tools, not leak detection |
| [Repoguard](https://github.com/rajaindian/RepoGuard) | Pre-install security scan for skills/MCP/npm | Low — supply-chain, not sample KPI drift |

### Samplebeacon differentiation (honest)

**Say:**
- Fiction KPI detection in `*-sample.json` vs measured baseline
- Production-path leaks (`-sample.json`, `web/data` in `server/`)
- Credential pattern scan (JSON + production JS)
- JSON schema drift for registered page specs
- Sub-second scan on typical repos

**Don't say:**
- “Detects all AI-generated fiction in arbitrary JS” (JSON samples only today)
- “Comprehensive security scanner” (pattern-based credentials, not full SAST)
- Unproven audit-time savings percentages

See also: [MARKETING.md](./MARKETING.md) for claim-by-claim verification.

---

## Names evaluated (May 2026)

### Selected: Samplebeacon

| Check | Result |
|-------|--------|
| npm `samplebeacon` | **404 Not Found** → name available (verified via `npm view samplebeacon`) |
| Major product at same name | None found |
| Describes product | Yes — warns when **sample** files contain fiction / leaks |
| CLI ergonomics | `npx samplebeacon scan --gate` |

### Runner-up: Fixturegate

| Check | Result |
|-------|--------|
| npm `fixturegate` | **404 Not Found** → available |
| Pros | Fits CI “gate” convention (covgate, GreenGate, Guardrail) |
| Cons | Sounds like **test fixtures only**, not KPI fiction or credentials |

### Rejected or crowded

| Name | Why not |
|------|---------|
| **Cascade AI** | Taken — gocascade.ai (enterprise HR/IT) |
| **Cascade Truthcheck** | “Cascade” collision + “Truthcheck” generic |
| **Truthcheck** | Generic; prior internal name only |
| **Mocklint** | Dead 2016 GitHub project; weak brand |
| **Mockbeacon** | “Mock” collides with Mockoon/mock-server ecosystem; `MockBeacon` exists as Rust internal type only |
| **Sampleguard** | Shopify app name noise; no dev-tool product but confusing |
| **baseline-check** | **Taken** — web platform Baseline linter |
| **Reporeality / Repofixture** | Blog posts and academic tools; no clear npm SKU |
| **Guardrail** | **Taken** — direct competitor |
| **Fictcheck / Antifiction** | Close to [fict](https://www.npmjs.com/package/fict) UI framework on npm |

### npm availability snapshot

```bash
npm view samplebeacon   # 404 → available
npm view fixturegate    # 404 → available
npm view @cascade/truthcheck  # was local workspace only; @cascade scope separate from gocascade.ai product
```

> **Note:** `npm view` returning exit code 1 with E404 means the package **does not exist** — that is the desired result for availability checks.

---

## Rename map (Truthcheck → Samplebeacon)

Applied in-repo at **v1.1.0** (May 2026).

| Before | After |
|--------|-------|
| `@cascade/truthcheck` | `samplebeacon` |
| `packages/truthcheck-cli/` | `packages/samplebeacon-cli/` |
| `bin/truthcheck.js` | `bin/samplebeacon.js` |
| `.truthcheck/` | `.samplebeacon/` |
| `npm run truthcheck*` | `npm run samplebeacon*` |
| `.github/workflows/truthcheck.yml` | `.github/workflows/samplebeacon.yml` |
| `web/data/truthcheck-cli-sample.json` | `web/data/samplebeacon-cli-sample.json` |
| `loadTruthcheckConfig()` | `loadSamplebeaconConfig()` |
| `initTruthcheck()` | `initSamplebeacon()` |
| Report type `truthcheck-report` | `samplebeacon-report` |

### npm scripts (ai-platform root)

```bash
npm run samplebeacon              # scan --gate
npm run samplebeacon:full         # scan --gate --with-jest
npm run samplebeacon:report       # JSON report + gate
npm run samplebeacon:comment      # PR comment from report
npm run samplebeacon:init         # init config + baseline
npm run samplebeacon:baseline-sync
```

### Residual internal IDs (cosmetic only)

Some dashboard sample JSON / help-page code still uses legacy ids like `truthcheck-gate`, `doc_truthcheck`, `truthcheckCliToHelpModel` — display strings already say Samplebeacon. Safe to clean up in a follow-up PR.

---

## Verification after rename

| Check | Result (May 2026) |
|-------|-------------------|
| Samplebeacon CLI tests | **28/28** pass |
| Dogfood gate on ai-platform | **PASS** (99/100, 0 issues) |
| Bulk file updates | 95 files across ai-platform + `.github` + `action/` |

---

## Pre-launch checklist

Use this before `npm publish` or public marketing.

- [ ] **Claim npm:** `npm publish` for `samplebeacon` (name verified available)
- [ ] **Domain:** check `samplebeacon.dev`, `.io`, `.com` (not verified in this doc)
- [ ] **Trademark:** USPTO / Google search for “Samplebeacon” in software/CI class
- [ ] **GitHub org/repo:** prefer `samplebeacon` or `samplebeacon-cli` over `cascade-*`
- [ ] **Migration note:** document `.truthcheck/` → `.samplebeacon/` for any external adopters
- [ ] **Optional:** `.truthcheck` fallback reader for one release (not implemented as of v1.1.0)
- [ ] **Competitive page:** honest comparison vs Guardrail (mock + fiction KPIs vs broader “fake features”)
- [ ] **Live proof:** external-repo PR comment test via GitHub Action

---

## Related docs

| Doc | Purpose |
|-----|---------|
| [MARKETING.md](./MARKETING.md) | Verified public claims |
| [RULES.md](./RULES.md) | Scanner rules reference |
| [CONFIG.md](./CONFIG.md) | `.samplebeacon/config.json` |
| [CI.md](./CI.md) | GitHub Actions integration |
| [../README.md](../README.md) | Product README |

---

## Open questions (for later research)

1. **Scoped package?** `@samplebeacon/cli` vs unscoped `samplebeacon` — unscoped chosen for simpler `npx samplebeacon`.
2. **Fixturegate rebrand?** Only if user testing shows “Samplebeacon” is unclear to devs outside this repo.
3. **`.truthcheck` compatibility shim?** Reduces friction for docs/blog posts referencing old name.
4. **Company name for npm org:** If not publishing under personal account, register npm org before squatters.
5. **International trademark:** gocascade.ai is US-focused; Samplebeacon still needs independent clearance.

---

## Changelog

| Date | Change |
|------|--------|
| 2026-05 | Initial naming research; rejected Cascade AI as product name |
| 2026-05 | Renamed Truthcheck → **Samplebeacon v1.1.0**; npm name `samplebeacon` verified available |
