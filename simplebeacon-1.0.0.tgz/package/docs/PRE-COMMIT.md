# Pre-commit & pre-push hooks (Community tier)

Community includes unlimited **local** scans with gate policy. Wire a hook once and Samplebeacon blocks fiction before it lands.

## One-command install

```bash
npx samplebeacon init
npx samplebeacon hook install              # .husky/pre-commit or .git/hooks/pre-commit
npx samplebeacon hook install --type pre-push --with-jest
```

Husky is used when `.husky/` exists; otherwise a plain Git hook is written under `.git/hooks/`. If the directory is not a Git repo, the script is saved under `.samplebeacon/hooks/` for manual wiring.

## Manual (copy/paste)

Copy [examples/hooks/pre-commit](../examples/hooks/pre-commit) to `.husky/pre-commit` or `.git/hooks/pre-commit` and `chmod +x` the file.

## npm scripts (alternative)

```json
{
  "scripts": {
    "samplebeacon:gate": "samplebeacon scan --gate --fail-on high",
    "prepare": "husky"
  }
}
```

Then in `.husky/pre-commit`:

```sh
npm run samplebeacon:gate
```

## What runs

| Hook | Command |
|------|---------|
| pre-commit | `samplebeacon scan --gate --fail-on high` |
| pre-push | `samplebeacon scan --gate --with-jest --fail-on high` |

Reports are printed to the terminal (text). Use `--format json --output .samplebeacon/report.json` in CI for artifacts.
